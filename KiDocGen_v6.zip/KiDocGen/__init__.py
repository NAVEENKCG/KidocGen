from .plugin import KiDocGenPlugin

KiDocGenPlugin().register()
