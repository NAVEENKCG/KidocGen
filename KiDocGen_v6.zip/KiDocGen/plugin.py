import os
import datetime
import traceback
import wx
import pcbnew

from .gui.input_dialog import ProjectInputDialog
from .core import pcb_reader, sch_reader, dimensions, bom, datasheets, screenshots, report


class KiDocGenPlugin(pcbnew.ActionPlugin):
    """
    KiDocGen - Phase 1
    Registers a toolbar button in the PCB Editor. Clicking it opens an
    HTML-based input dialog to collect report details, then (for now)
    just echoes back what was entered. Report generation logic will be
    added in later phases.
    """

    def defaults(self):
        self.name = "KiDocGen - Generate Report"
        self.category = "Documentation"
        self.description = "Generate a professional PCB engineering report"
        self.show_toolbar_button = True

        icon_path = os.path.join(os.path.dirname(__file__), "resources", "icon.png")
        if os.path.exists(icon_path):
            self.icon_file_name = icon_path

    def Run(self):
        board = pcbnew.GetBoard()
        board_path = board.GetFileName()
        project_dir = os.path.dirname(board_path) if board_path else os.getcwd()

        dialog = ProjectInputDialog(None, default_project_dir=project_dir)
        result = dialog.ShowModal()

        if result == wx.ID_OK:
            data = dialog.get_form_data()
            dialog.Destroy()
            self._on_submit(data)
        else:
            dialog.Destroy()

    def _on_submit(self, data):
        try:
            output_path, warnings = self._generate_report(data)
        except Exception as exc:
            wx.MessageBox(
                f"Report generation failed:\n\n{exc}\n\n{traceback.format_exc()}",
                "KiDocGen - Error",
                wx.OK | wx.ICON_ERROR,
            )
            return

        message = f"Report generated successfully:\n\n{output_path}"
        if warnings:
            message += "\n\nWarnings (report still generated, just missing these parts):\n"
            message += "\n".join(f"- {w}" for w in warnings)

        wx.MessageBox(
            message,
            "KiDocGen",
            wx.OK | wx.ICON_INFORMATION if not warnings else wx.OK | wx.ICON_WARNING,
        )

    def _generate_report(self, data):
        board = pcbnew.GetBoard()
        board_path = board.GetFileName()
        project_dir = os.path.dirname(board_path) if board_path else os.getcwd()
        output_dir = data.get("output_dir") or project_dir
        os.makedirs(output_dir, exist_ok=True)

        # 1. Read PCB
        pcb_data = pcb_reader.read_board(board)

        # 2. Measure board
        dims = dimensions.measure_board(board)
        board_stats = {**dims, **pcb_data["summary"]}

        # 3. Read schematic (if found)
        root_sch = sch_reader.find_root_schematic(project_dir)
        sch_symbols = sch_reader.parse_schematic(root_sch) if root_sch else []

        # 4. Generate BOM
        components = bom.build_component_list(sch_symbols, pcb_data["footprints"])
        bom_rows = bom.group_bom(components)
        cat_counts = bom.category_counts(components)

        # 5. Collect datasheet links
        ds_list = datasheets.collect_datasheets(bom_rows)

        # 6. Export PCB images (real PNG via kicad-cli pcb render)
        image_paths = {}
        warnings = []
        try:
            pcb_images = screenshots.export_pcb_png(board_path, output_dir)
            image_paths["PCB Top"] = pcb_images.get("top")
            image_paths["PCB Bottom"] = pcb_images.get("bottom")
        except Exception as exc:
            warnings.append(f"PCB image export skipped: {exc}")

        # 7. Export schematic image (PNG direct, or SVG+converted fallback)
        if root_sch:
            try:
                sch_out_dir = os.path.join(output_dir, "schematic_png")
                sch_png = screenshots.export_schematic_png(root_sch, sch_out_dir)
                if sch_png:
                    image_paths["Schematic"] = sch_png
            except Exception as exc:
                warnings.append(f"Schematic image export skipped: {exc}")

        # 8. Generate the professional PDF
        project_info = {
            "project_name": data.get("project_name", ""),
            "designer": data.get("designer", ""),
            "version": data.get("version", ""),
            "date": datetime.date.today().isoformat(),
            "board_file": board_path,
        }
        pdf_path = os.path.join(
            output_dir,
            f"{project_info['project_name'] or 'KiDocGen'}_report.pdf".replace(" ", "_"),
        )
        report.build_pdf(
            pdf_path, project_info, board_stats, cat_counts,
            bom_rows, ds_list, image_paths,
        )
        return pdf_path, warnings
