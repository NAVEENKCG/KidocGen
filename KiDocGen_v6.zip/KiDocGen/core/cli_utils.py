"""
Finds kicad-cli even on machines where it's not on PATH (very common on
Windows portable-style installs, where kicad-cli.exe sits right next to
python.exe but neither is registered globally).
"""

import os
import shutil
import sys


def find_kicad_cli():
    """
    1. Check PATH first - works out of the box on Linux/macOS and on
       Windows installs where the user added KiCad's bin folder to PATH.
    2. Fall back to the folder containing the running Python interpreter
       (sys.executable) - on typical KiCad Windows installs, kicad-cli.exe
       lives in that exact same folder as python.exe, kicad.exe, etc.
    Returns a usable path/command string, or None if not found anywhere.
    """
    found = shutil.which("kicad-cli")
    if found:
        return found

    exe_dir = os.path.dirname(sys.executable)
    for name in ("kicad-cli.exe", "kicad-cli"):
        candidate = os.path.join(exe_dir, name)
        if os.path.exists(candidate):
            return candidate

    return None
