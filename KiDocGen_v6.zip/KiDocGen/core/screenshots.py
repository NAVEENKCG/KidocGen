"""
Image export - produces real PNG images for the PDF report.

PCB images: `kicad-cli pcb render` (ships with KiCad 8+) produces a
proper raytraced PNG directly - no conversion step needed.

Schematic images: some newer kicad-cli builds support `sch export png`
directly, but it is NOT available on all KiCad 10.0 releases (it only
appeared in very recent development builds at the time this was written).
So this tries the direct PNG export first, and if that subcommand
doesn't exist on the installed kicad-cli, falls back to `sch export svg`
followed by a pure-Python SVG->PNG conversion via svglib + reportlab
(no native Cairo dependency, so it installs cleanly via pip anywhere
reportlab already works).
"""

import os
import subprocess

from .cli_utils import find_kicad_cli


def _run(cmd):
    result = subprocess.run(cmd, capture_output=True, text=True)
    if result.returncode != 0:
        raise RuntimeError(
            f"Command failed: {' '.join(cmd)}\n{result.stderr or result.stdout}"
        )
    return result


def export_pcb_png(board_path, output_dir, width=1600, height=1200):
    """
    Renders top and bottom PNG views of the board using `kicad-cli pcb render`.
    Returns {"top": path, "bottom": path}.
    Raises RuntimeError if kicad-cli can't be found or the render fails -
    callers should catch this, since missing images shouldn't block the
    rest of the report from generating.
    """
    cli = find_kicad_cli()
    if not cli:
        raise RuntimeError(
            "kicad-cli not found on PATH or next to KiCad's Python interpreter"
        )

    os.makedirs(output_dir, exist_ok=True)
    results = {}
    for side in ("top", "bottom"):
        out_path = os.path.join(output_dir, f"pcb_{side}.png")
        cmd = [
            cli, "pcb", "render",
            "--output", out_path,
            "--side", side,
            "--width", str(width),
            "--height", str(height),
            "--background", "white",
            "--quality", "high",
            board_path,
        ]
        _run(cmd)
        results[side] = out_path
    return results


def export_schematic_png(root_sch_path, output_dir):
    """
    Exports the schematic to PNG.
    Tries `sch export png` first (newer kicad-cli builds). If that
    subcommand isn't recognized on this KiCad version, falls back to
    `sch export svg` + svglib conversion.
    Returns a path to a PNG (or, as a last resort, the raw SVG path if
    svglib isn't installed), or None if nothing could be exported.
    """
    cli = find_kicad_cli()
    if not cli:
        raise RuntimeError(
            "kicad-cli not found on PATH or next to KiCad's Python interpreter"
        )

    os.makedirs(output_dir, exist_ok=True)

    # Attempt 1: direct PNG export
    try:
        _run([cli, "sch", "export", "png", "--output", output_dir, root_sch_path])
        pngs = sorted(f for f in os.listdir(output_dir) if f.lower().endswith(".png"))
        if pngs:
            return os.path.join(output_dir, pngs[0])
    except RuntimeError:
        pass  # this kicad-cli build doesn't support "sch export png" - fall back

    # Attempt 2: SVG export + pure-Python conversion
    _run([cli, "sch", "export", "svg", "--output", output_dir, root_sch_path])
    svgs = sorted(f for f in os.listdir(output_dir) if f.lower().endswith(".svg"))
    if not svgs:
        return None

    svg_path = os.path.join(output_dir, svgs[0])
    return convert_svg_to_png(svg_path)


def convert_svg_to_png(svg_path):
    """
    Converts a single SVG file to PNG next to it, using svglib + reportlab
    (both pure Python / pip-installable, no native Cairo dependency).
    Returns the PNG path, or the original SVG path if svglib isn't
    installed (report.py will then just note the file instead of
    embedding it).
    """
    png_path = os.path.splitext(svg_path)[0] + ".png"
    try:
        from svglib.svglib import svg2rlg
        from reportlab.graphics import renderPM
    except ImportError:
        return svg_path

    drawing = svg2rlg(svg_path)
    renderPM.drawToFile(drawing, png_path, fmt="PNG")
    return png_path
