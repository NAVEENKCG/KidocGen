"""
Board dimension measurement - must run inside KiCad (uses pcbnew).
"""

import pcbnew


def measure_board(board):
    """
    Returns board physical dimensions in mm, derived from the Edge.Cuts
    bounding box and the design settings' board thickness.
    """
    bbox = board.GetBoardEdgesBoundingBox()

    width_mm = pcbnew.ToMM(bbox.GetWidth())
    height_mm = pcbnew.ToMM(bbox.GetHeight())

    thickness_mm = pcbnew.ToMM(
        board.GetDesignSettings().GetBoardThickness()
    )

    area_mm2 = width_mm * height_mm
    perimeter_mm = 2 * (width_mm + height_mm)

    return {
        "width_mm": round(width_mm, 2),
        "height_mm": round(height_mm, 2),
        "thickness_mm": round(thickness_mm, 2),
        "area_mm2": round(area_mm2, 2),
        "perimeter_mm": round(perimeter_mm, 2),
    }
