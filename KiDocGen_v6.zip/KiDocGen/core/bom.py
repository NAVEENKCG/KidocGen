"""
BOM builder - pure Python, no pcbnew dependency, fully testable outside KiCad.

Combines:
  - schematic symbols (authoritative for Value / Footprint / Datasheet)
  - PCB footprints (authoritative for "is it actually still placed on
    the board", since a symbol can exist in schematic but be deleted
    from the PCB, or vice versa for mechanical-only footprints)
"""

import re

CATEGORY_RULES = [
    (r"^R\d*$", "Resistor"),
    (r"^C\d*$", "Capacitor"),
    (r"^U\d*$", "IC"),
    (r"^Q\d*$", "Transistor"),
    (r"^D\d*$", "Diode"),
    (r"^LED\d*$", "LED"),
    (r"^J\d*$", "Connector"),
    (r"^CN\d*$", "Connector"),
    (r"^L\d*$", "Inductor"),
    (r"^Y\d*$", "Crystal/Oscillator"),
    (r"^X\d*$", "Crystal/Oscillator"),
    (r"^SW\d*$", "Switch"),
    (r"^TP\d*$", "Test Point"),
    (r"^F\d*$", "Fuse"),
    (r"^K\d*$", "Relay"),
]


def categorize(reference):
    """Classify a reference designator like 'R14' or 'U2' into a category."""
    prefix = re.match(r"^[A-Za-z_]+", reference)
    prefix = prefix.group(0).upper() if prefix else reference.upper()

    for pattern, category in CATEGORY_RULES:
        if re.match(pattern, prefix + "1"):  # normalize e.g. "R" -> "R1"
            return category

    # Special case: D-prefixed parts whose value/footprint hints "LED"
    return "Other"


def categorize_component(reference, value="", footprint=""):
    """More accurate categorizer that also looks at Value/Footprint text."""
    ref_upper = reference.upper()
    combined = f"{value} {footprint}".upper()

    if ref_upper.startswith("R"):
        return "Resistor"
    if ref_upper.startswith("C"):
        return "Capacitor"
    if ref_upper.startswith("U"):
        return "IC"
    if ref_upper.startswith("Q"):
        return "Transistor"
    if ref_upper.startswith("D"):
        return "LED" if "LED" in combined else "Diode"
    if ref_upper.startswith(("J", "CN")):
        return "Connector"
    if ref_upper.startswith("L"):
        return "Inductor"
    if ref_upper.startswith(("Y", "X")):
        return "Crystal/Oscillator"
    if ref_upper.startswith("SW"):
        return "Switch"
    if ref_upper.startswith("TP"):
        return "Test Point"
    if ref_upper.startswith("F"):
        return "Fuse"
    if ref_upper.startswith("K"):
        return "Relay"
    return "Other"


def build_component_list(sch_symbols, pcb_footprints):
    """
    Returns one row per physical component (not yet grouped), preferring
    schematic data but falling back to PCB data if a reference only
    exists on one side.
    """
    sch_by_ref = {s["reference"]: s for s in sch_symbols}
    pcb_by_ref = {f["reference"]: f for f in pcb_footprints}

    all_refs = sorted(set(sch_by_ref) | set(pcb_by_ref),
                       key=lambda r: (re.match(r"^[A-Za-z_]+", r).group(0)
                                      if re.match(r"^[A-Za-z_]+", r) else r,
                                      r))

    rows = []
    for ref in all_refs:
        sch = sch_by_ref.get(ref, {})
        pcb = pcb_by_ref.get(ref, {})

        value = sch.get("value") or pcb.get("value") or ""
        footprint = sch.get("footprint") or pcb.get("footprint") or ""
        datasheet = sch.get("datasheet", "")

        rows.append({
            "reference": ref,
            "value": value,
            "footprint": footprint,
            "datasheet": "" if datasheet == "~" else datasheet,
            "category": categorize_component(ref, value, footprint),
            "on_pcb": ref in pcb_by_ref,
            "in_schematic": ref in sch_by_ref,
        })
    return rows


def group_bom(component_rows):
    """
    Groups identical (value, footprint) combinations together into a
    proper BOM line (Ref list + Qty), the way KiCad's own BOM tool does.
    """
    groups = {}
    order = []
    for row in component_rows:
        key = (row["value"], row["footprint"])
        if key not in groups:
            groups[key] = {
                "value": row["value"],
                "footprint": row["footprint"],
                "datasheet": row["datasheet"],
                "category": row["category"],
                "references": [],
            }
            order.append(key)
        groups[key]["references"].append(row["reference"])
        if not groups[key]["datasheet"] and row["datasheet"]:
            groups[key]["datasheet"] = row["datasheet"]

    bom_rows = []
    for key in order:
        g = groups[key]
        refs_sorted = sorted(
            g["references"],
            key=lambda r: (re.match(r"^[A-Za-z_]+", r).group(0), r)
        )
        bom_rows.append({
            "references": refs_sorted,
            "reference_range": _compress_refs(refs_sorted),
            "value": g["value"],
            "footprint": g["footprint"],
            "qty": len(refs_sorted),
            "datasheet": g["datasheet"],
            "category": g["category"],
        })
    return bom_rows


def _compress_refs(refs):
    """['R1','R2','R3','R7'] -> 'R1-R3, R7' for compact display."""
    if not refs:
        return ""
    if len(refs) == 1:
        return refs[0]

    prefix = re.match(r"^[A-Za-z_]+", refs[0]).group(0)
    nums = []
    for r in refs:
        m = re.match(rf"^{re.escape(prefix)}(\d+)$", r)
        nums.append(int(m.group(1)) if m else None)

    if any(n is None for n in nums):
        return ", ".join(refs)

    nums = sorted(nums)
    ranges = []
    start = prev = nums[0]
    for n in nums[1:]:
        if n == prev + 1:
            prev = n
            continue
        ranges.append((start, prev))
        start = prev = n
    ranges.append((start, prev))

    parts = [f"{prefix}{a}" if a == b else f"{prefix}{a}-{prefix}{b}"
             for a, b in ranges]
    return ", ".join(parts)


def category_counts(component_rows):
    """Returns {category: count} for the board statistics page."""
    counts = {}
    for row in component_rows:
        counts[row["category"]] = counts.get(row["category"], 0) + 1
    return counts
