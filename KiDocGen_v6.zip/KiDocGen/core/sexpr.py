"""
Minimal S-expression parser.

KiCad schematic files (.kicad_sch) are plain S-expressions, e.g.:

    (kicad_sch (version 20230121) (generator eeschema)
      (symbol (lib_id "Device:R") (at 100 50 0)
        (property "Reference" "R1" (at 102 48 0))
        (property "Value" "10k" (at 102 52 0))
      )
    )

No external library (kiutils, sexpdata, etc.) is required to read this -
KiCad's bundled Python interpreter may not have those installed, so this
plugin ships its own tiny, dependency-free parser instead.
"""


def tokenize(text):
    tokens = []
    i = 0
    n = len(text)
    while i < n:
        ch = text[i]

        if ch in " \t\r\n":
            i += 1
            continue

        if ch == "(":
            tokens.append("(")
            i += 1
            continue

        if ch == ")":
            tokens.append(")")
            i += 1
            continue

        if ch == '"':
            j = i + 1
            buf = []
            while j < n and text[j] != '"':
                if text[j] == "\\" and j + 1 < n:
                    buf.append(text[j + 1])
                    j += 2
                else:
                    buf.append(text[j])
                    j += 1
            tokens.append(("str", "".join(buf)))
            i = j + 1
            continue

        # bare atom (symbol, number, yes/no, etc.)
        j = i
        while j < n and text[j] not in " \t\r\n()":
            j += 1
        tokens.append(("atom", text[i:j]))
        i = j

    return tokens


def _parse_tokens(tokens, pos):
    """Recursively build nested lists from the flat token stream."""
    node = []
    while pos < len(tokens):
        tok = tokens[pos]
        if tok == "(":
            child, pos = _parse_tokens(tokens, pos + 1)
            node.append(child)
        elif tok == ")":
            return node, pos + 1
        else:
            kind, value = tok
            node.append(value)
            pos += 1
    return node, pos


def parse_sexpr(text):
    """
    Parse a full S-expression file and return the top-level list.
    For a .kicad_sch file this returns something like:
        ["kicad_sch", ["version", "20230121"], ["symbol", ...], ...]
    """
    tokens = tokenize(text)
    # The file is one top-level (...) form; strip the outer wrapper.
    if tokens and tokens[0] == "(":
        node, _ = _parse_tokens(tokens, 1)
        return node
    node, _ = _parse_tokens(tokens, 0)
    return node


def find_all(node, tag):
    """
    Recursively find every sub-list whose first element equals `tag`.
    Example: find_all(tree, "symbol") -> list of ["symbol", ...] nodes
    """
    results = []
    if isinstance(node, list):
        if node and node[0] == tag:
            results.append(node)
        for child in node:
            if isinstance(child, list):
                results.extend(find_all(child, tag))
    return results


def get_property(symbol_node, prop_name):
    """
    Given a ["symbol", ...] node, return the value of
    (property "PropName" "value" ...) or None if not present.
    """
    for child in symbol_node:
        if isinstance(child, list) and len(child) >= 3 and child[0] == "property":
            if child[1] == prop_name:
                return child[2]
    return None


def get_atom_flag(symbol_node, flag_name, default=None):
    """
    Given a ["symbol", ...] node, return the value of a bare flag like
    (dnp yes) or (on_board no) as a lowercase string ("yes"/"no"),
    or `default` if the flag isn't present.
    """
    for child in symbol_node:
        if isinstance(child, list) and len(child) >= 2 and child[0] == flag_name:
            return str(child[1]).lower()
    return default
