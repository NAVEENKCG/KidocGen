"""
Schematic reader.

KiCad's ActionPlugin runs inside the PCB Editor process, which does NOT
have a live handle on the schematic (that's Eeschema's job). So instead
of a scripting API, we read the .kicad_sch file(s) directly from disk -
they're just S-expression text files (see sexpr.py).

This also follows hierarchical sheets: a top .kicad_sch can reference
sub-sheets via (sheet ... (property "Sheetfile" "sub.kicad_sch")), and
this walks into those recursively so a multi-sheet schematic is fully
covered.
"""

import os

from .sexpr import parse_sexpr, get_property, get_atom_flag

# lib_id prefixes that are not real BOM components (power symbols,
# ground symbols, no-connect flags, etc.)
NON_BOM_LIB_PREFIXES = ("power:", "Mechanical:")


def _read_file(path):
    with open(path, "r", encoding="utf-8", errors="replace") as f:
        return f.read()


def _direct_children(tree, tag):
    """
    Every .kicad_sch file's top-level list also contains a `lib_symbols`
    block: a library of generic part TEMPLATES (e.g. a bare "R" or "C"
    with no real reference), copied into the file so it's self-contained.
    Those templates are NOT placed components - real placed instances
    only ever appear as direct top-level children of the file, never
    nested inside lib_symbols.

    Using a recursive search (like sexpr.find_all) here would also match
    those library templates, producing bogus BOM rows like a bare "R" or
    "C" with no real designator. So this only looks at direct children
    of the top-level list, which correctly skips lib_symbols entirely.
    """
    return [child for child in tree
            if isinstance(child, list) and child and child[0] == tag]


def _parse_one_file(sch_path, visited, symbols_out):
    sch_path = os.path.abspath(sch_path)
    if sch_path in visited or not os.path.exists(sch_path):
        return
    visited.add(sch_path)

    tree = parse_sexpr(_read_file(sch_path))

    for sym in _direct_children(tree, "symbol"):
        lib_id = None
        for child in sym:
            if isinstance(child, list) and len(child) >= 2 and child[0] == "lib_id":
                lib_id = child[1]
                break

        if lib_id and lib_id.startswith(NON_BOM_LIB_PREFIXES):
            continue

        reference = get_property(sym, "Reference")
        if not reference or reference.startswith("#"):
            # "#PWR01" style hidden power symbols - skip
            continue
        if reference.startswith("REF"):
            # KiCad's convention for graphics-only symbols (compliance
            # logos, mounting-hole markers, etc.) that aren't real
            # components, e.g. "REF**"
            continue

        symbols_out.append({
            "reference": reference,
            "value": get_property(sym, "Value") or "",
            "footprint": get_property(sym, "Footprint") or "",
            "datasheet": get_property(sym, "Datasheet") or "",
            "lib_id": lib_id or "",
            "in_bom": get_atom_flag(sym, "in_bom", "yes") == "yes",
            "on_board": get_atom_flag(sym, "on_board", "yes") == "yes",
            "dnp": get_atom_flag(sym, "dnp", "no") == "yes",
            "source_sheet": os.path.basename(sch_path),
        })

    # Follow hierarchical sub-sheets (also direct top-level children only)
    base_dir = os.path.dirname(sch_path)
    for sheet in _direct_children(tree, "sheet"):
        sheet_file = get_property(sheet, "Sheetfile")
        if sheet_file:
            _parse_one_file(os.path.join(base_dir, sheet_file), visited, symbols_out)


def parse_schematic(root_sch_path):
    """
    Parse a root .kicad_sch file and all of its hierarchical sub-sheets.
    Returns a flat list of component dicts:
        {reference, value, footprint, datasheet, lib_id,
         in_bom, on_board, dnp, source_sheet}
    """
    symbols = []
    visited = set()
    _parse_one_file(root_sch_path, visited, symbols)
    # Keep only parts meant to appear in the BOM and not marked DNP
    return [s for s in symbols if s["in_bom"] and not s["dnp"]]


def find_root_schematic(project_dir):
    """
    Given a project folder, guess the root .kicad_sch file: the one whose
    name matches a .kicad_pro file in the same folder, falling back to
    the first .kicad_sch found.
    """
    pro_files = [f for f in os.listdir(project_dir) if f.endswith(".kicad_pro")]
    if pro_files:
        candidate = os.path.join(
            project_dir, os.path.splitext(pro_files[0])[0] + ".kicad_sch"
        )
        if os.path.exists(candidate):
            return candidate

    sch_files = [f for f in os.listdir(project_dir) if f.endswith(".kicad_sch")]
    if sch_files:
        return os.path.join(project_dir, sch_files[0])

    return None
