"""
Report generator - pure Python (reportlab only), no pcbnew dependency.
Takes plain dicts/lists produced by the other core modules and renders
the final PDF. This keeps report layout testable outside KiCad.
"""

import os

from reportlab.lib.pagesizes import A4
from reportlab.lib.units import mm
from reportlab.lib import colors
from reportlab.lib.styles import getSampleStyleSheet, ParagraphStyle
from reportlab.platypus import (
    BaseDocTemplate, PageTemplate, Frame, NextPageTemplate,
    Paragraph, Spacer, Table, TableStyle,
    PageBreak, Image as RLImage
)
from reportlab.lib.enums import TA_CENTER

PAGE_W, PAGE_H = A4
NAVY = colors.HexColor("#12233f")
ACCENT = colors.HexColor("#2d7dd2")
LIGHT_GREY = colors.HexColor("#f2f4f7")
MID_GREY = colors.HexColor("#6b7280")

styles = getSampleStyleSheet()

title_style = ParagraphStyle("TitleBig", parent=styles["Title"], fontSize=26,
                              textColor=colors.white, alignment=TA_CENTER, spaceAfter=6)
subtitle_style = ParagraphStyle("SubtitleBig", parent=styles["Normal"], fontSize=13,
                                 textColor=colors.white, alignment=TA_CENTER)
brand_style = ParagraphStyle("Brand", parent=styles["Normal"], fontSize=14,
                              textColor=ACCENT, alignment=TA_CENTER, spaceAfter=30)
section_heading = ParagraphStyle("SectionHeading", parent=styles["Heading1"],
                                  fontSize=15, textColor=NAVY, spaceAfter=10)
label_style = ParagraphStyle("Label", parent=styles["Normal"], fontSize=9, textColor=MID_GREY)
value_style = ParagraphStyle("Value", parent=styles["Normal"], fontSize=11,
                              textColor=NAVY, fontName="Helvetica-Bold")
meta_k_style = ParagraphStyle("k", parent=styles["Normal"], fontSize=10,
                               textColor=colors.HexColor("#c9d3e0"), alignment=TA_CENTER)
meta_v_style = ParagraphStyle("v", parent=styles["Normal"], fontSize=11,
                               textColor=colors.white, fontName="Helvetica-Bold",
                               alignment=TA_CENTER)
caption_style = ParagraphStyle("Caption", parent=styles["Normal"], fontSize=8.5,
                                textColor=MID_GREY, alignment=TA_CENTER, spaceBefore=4)


def _info_card(rows, col_widths=None):
    data = [[Paragraph(k, label_style), Paragraph(str(v), value_style)] for k, v in rows]
    t = Table(data, colWidths=col_widths or [45 * mm, 100 * mm])
    t.setStyle(TableStyle([
        ("BACKGROUND", (0, 0), (-1, -1), LIGHT_GREY),
        ("BOX", (0, 0), (-1, -1), 0.5, colors.HexColor("#dfe3e8")),
        ("INNERGRID", (0, 0), (-1, -1), 0.5, colors.HexColor("#dfe3e8")),
        ("LEFTPADDING", (0, 0), (-1, -1), 10),
        ("TOPPADDING", (0, 0), (-1, -1), 7),
        ("BOTTOMPADDING", (0, 0), (-1, -1), 7),
    ]))
    return t


def _cover_page(story, project_info):
    story.append(Spacer(1, 55 * mm))
    story.append(Paragraph("KiDocGen", brand_style))
    story.append(Paragraph("PCB Engineering Report", title_style))
    story.append(Paragraph(project_info.get("project_name", ""), subtitle_style))
    story.append(Spacer(1, 35 * mm))

    meta_rows = [
        ["Designer", project_info.get("designer", "") or "\u2014"],
        ["Version", project_info.get("version", "") or "\u2014"],
        ["Date", project_info.get("date", "")],
        ["Board File", os.path.basename(project_info.get("board_file", "") or "")],
    ]
    rows = [[Paragraph(k, meta_k_style), Paragraph(v, meta_v_style)] for k, v in meta_rows]
    t = Table(rows, colWidths=[35 * mm, 100 * mm])
    t.setStyle(TableStyle([("ALIGN", (0, 0), (-1, -1), "CENTER"),
                           ("BOTTOMPADDING", (0, 0), (-1, -1), 6)]))
    story.append(t)
    story.append(PageBreak())


def _project_info_and_stats_page(story, project_info, board_stats, category_counts):
    story.append(Spacer(1, 4 * mm))
    story.append(Paragraph("Project Information", section_heading))
    story.append(_info_card([
        ("Board Name", project_info.get("project_name", "")),
        ("Revision", project_info.get("version", "") or "\u2014"),
        ("Layers", f"{board_stats.get('copper_layer_count', '?')}"),
        ("Board Size",
         f"{board_stats.get('width_mm', '?')} mm \u00d7 {board_stats.get('height_mm', '?')} mm"),
        ("Thickness", f"{board_stats.get('thickness_mm', '?')} mm"),
        ("Designer", project_info.get("designer", "") or "\u2014"),
    ]))
    story.append(Spacer(1, 10 * mm))
    story.append(Paragraph("Board Statistics", section_heading))

    stat_rows = [["Metric", "Count"]]
    stat_rows.append(["Total Components", str(sum(category_counts.values()))])
    for cat, count in sorted(category_counts.items(), key=lambda x: -x[1]):
        stat_rows.append([cat, str(count)])
    stat_rows.append(["Tracks", str(board_stats.get("track_count", "?"))])
    stat_rows.append(["Vias", str(board_stats.get("via_count", "?"))])
    stat_rows.append(["Pads", str(board_stats.get("pad_count", "?"))])
    stat_rows.append(["Nets", str(board_stats.get("net_count", "?"))])

    t = Table(stat_rows, colWidths=[90 * mm, 55 * mm])
    t.setStyle(TableStyle([
        ("BACKGROUND", (0, 0), (-1, 0), NAVY),
        ("TEXTCOLOR", (0, 0), (-1, 0), colors.white),
        ("FONTNAME", (0, 0), (-1, 0), "Helvetica-Bold"),
        ("FONTSIZE", (0, 0), (-1, -1), 9.5),
        ("ROWBACKGROUNDS", (0, 1), (-1, -1), [colors.white, LIGHT_GREY]),
        ("GRID", (0, 0), (-1, -1), 0.4, colors.HexColor("#dfe3e8")),
        ("TOPPADDING", (0, 0), (-1, -1), 5),
        ("BOTTOMPADDING", (0, 0), (-1, -1), 5),
        ("ALIGN", (1, 0), (1, -1), "CENTER"),
    ]))
    story.append(t)
    story.append(PageBreak())


def _images_page(story, image_paths):
    if not image_paths:
        return
    story.append(Spacer(1, 4 * mm))
    story.append(Paragraph("Board & Schematic Images", section_heading))

    for label, path in image_paths.items():
        if path and os.path.exists(path) and path.lower().endswith((".png", ".jpg", ".jpeg")):
            story.append(Paragraph(label, ParagraphStyle(
                "imglabel", parent=styles["Normal"], fontSize=10, textColor=NAVY,
                spaceBefore=8, spaceAfter=4)))
            img = RLImage(path, width=160 * mm, height=90 * mm, kind="proportional")
            story.append(img)
        elif path:
            story.append(Paragraph(
                f"{label}: exported to <font face='Courier'>{path}</font> "
                f"(SVG - embed as PNG for print, or view directly)",
                caption_style
            ))
    story.append(PageBreak())


def _bom_page(story, bom_rows):
    story.append(Spacer(1, 4 * mm))
    story.append(Paragraph("Bill of Materials", section_heading))

    table_data = [["Ref", "Value", "Footprint", "Qty", "Datasheet"]]
    for row in bom_rows:
        ds = row["datasheet"]
        ds_display = ds if not ds.startswith("http") else "See index"
        table_data.append([
            row["reference_range"], row["value"], row["footprint"],
            str(row["qty"]), ds_display or "\u2014",
        ])

    t = Table(table_data, colWidths=[28 * mm, 35 * mm, 55 * mm, 12 * mm, 25 * mm])
    t.setStyle(TableStyle([
        ("BACKGROUND", (0, 0), (-1, 0), NAVY),
        ("TEXTCOLOR", (0, 0), (-1, 0), colors.white),
        ("FONTNAME", (0, 0), (-1, 0), "Helvetica-Bold"),
        ("FONTSIZE", (0, 0), (-1, -1), 8),
        ("ROWBACKGROUNDS", (0, 1), (-1, -1), [colors.white, LIGHT_GREY]),
        ("GRID", (0, 0), (-1, -1), 0.4, colors.HexColor("#dfe3e8")),
        ("TOPPADDING", (0, 0), (-1, -1), 4),
        ("BOTTOMPADDING", (0, 0), (-1, -1), 4),
        ("ALIGN", (3, 0), (3, -1), "CENTER"),
    ]))
    story.append(t)
    story.append(PageBreak())


def _datasheet_index_page(story, datasheets):
    story.append(Spacer(1, 4 * mm))
    story.append(Paragraph("Datasheet Index", section_heading))

    if not datasheets:
        story.append(Paragraph("No datasheet links found in the schematic.",
                                styles["Normal"]))
        return

    table_data = [["Component", "Reference(s)", "Datasheet"]]
    for d in datasheets:
        table_data.append([d["value"], d["reference_range"], d["datasheet"]])

    t = Table(table_data, colWidths=[45 * mm, 30 * mm, 80 * mm])
    t.setStyle(TableStyle([
        ("BACKGROUND", (0, 0), (-1, 0), NAVY),
        ("TEXTCOLOR", (0, 0), (-1, 0), colors.white),
        ("FONTNAME", (0, 0), (-1, 0), "Helvetica-Bold"),
        ("FONTSIZE", (0, 0), (-1, -1), 8),
        ("ROWBACKGROUNDS", (0, 1), (-1, -1), [colors.white, LIGHT_GREY]),
        ("GRID", (0, 0), (-1, -1), 0.4, colors.HexColor("#dfe3e8")),
        ("TOPPADDING", (0, 0), (-1, -1), 4),
        ("BOTTOMPADDING", (0, 0), (-1, -1), 4),
    ]))
    story.append(t)


def _page_header(canvas, doc, project_info):
    canvas.saveState()
    if doc.page == 1:
        canvas.setFillColor(NAVY)
        canvas.rect(0, 0, PAGE_W, PAGE_H, fill=1, stroke=0)
    else:
        canvas.setFillColor(NAVY)
        canvas.rect(0, PAGE_H - 20 * mm, PAGE_W, 20 * mm, fill=1, stroke=0)
        canvas.setFillColor(colors.white)
        canvas.setFont("Helvetica-Bold", 10)
        canvas.drawString(18 * mm, PAGE_H - 13 * mm, "KiDocGen Report")
        canvas.setFont("Helvetica", 9)
        canvas.drawRightString(PAGE_W - 18 * mm, PAGE_H - 13 * mm,
                                project_info.get("project_name", ""))
        canvas.setFillColor(MID_GREY)
        canvas.setFont("Helvetica", 8)
        canvas.drawString(18 * mm, 10 * mm, "Generated by KiDocGen")
        canvas.drawRightString(PAGE_W - 18 * mm, 10 * mm, f"Page {doc.page}")
    canvas.restoreState()


def build_pdf(output_path, project_info, board_stats, category_counts,
              bom_rows, datasheets, image_paths=None):
    """
    Renders the final PDF report.

    project_info    : {project_name, designer, version, date, board_file}
    board_stats     : output of core.dimensions.measure_board() merged with
                       core.pcb_reader.read_board_summary()
    category_counts : output of core.bom.category_counts()
    bom_rows        : output of core.bom.group_bom()
    datasheets      : output of core.datasheets.collect_datasheets()
    image_paths     : optional {"PCB Top": path, "PCB Bottom": path,
                                  "Schematic": path}

    Uses two page templates instead of a manual top spacer:
      - "Cover"   : full-bleed frame (page 1, navy background, no header bar)
      - "Content" : a frame that starts BELOW the 20mm header bar

    This matters because content can overflow onto a new page automatically
    (e.g. a tall image doesn't fit) as well as via an explicit PageBreak().
    A fixed-size Spacer only protects against the second case; the frame
    itself protects against both, so nothing can ever render underneath
    the header bar regardless of how a page break happens.
    """
    doc = BaseDocTemplate(
        output_path, pagesize=A4,
        leftMargin=18 * mm, rightMargin=18 * mm,
        topMargin=0, bottomMargin=18 * mm,
    )

    header_h = 20 * mm
    cover_frame = Frame(
        0, 0, PAGE_W, PAGE_H,
        leftPadding=0, rightPadding=0, topPadding=0, bottomPadding=0,
        id="cover",
    )
    content_frame = Frame(
        18 * mm, 18 * mm,
        PAGE_W - 36 * mm, PAGE_H - header_h - 18 * mm,
        leftPadding=0, rightPadding=0, topPadding=6 * mm, bottomPadding=0,
        id="content",
    )

    def on_cover(canvas, doc_):
        _page_header(canvas, doc_, project_info)

    def on_content(canvas, doc_):
        _page_header(canvas, doc_, project_info)

    doc.addPageTemplates([
        PageTemplate(id="Cover", frames=[cover_frame], onPage=on_cover),
        PageTemplate(id="Content", frames=[content_frame], onPage=on_content),
    ])

    story = []
    _cover_page(story, project_info)
    story.append(NextPageTemplate("Content"))
    story.append(PageBreak())
    _project_info_and_stats_page(story, project_info, board_stats, category_counts)
    _images_page(story, image_paths or {})
    _bom_page(story, bom_rows)
    _datasheet_index_page(story, datasheets)

    doc.build(story)
    return output_path
