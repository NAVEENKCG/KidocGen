"""
PCB reader - reads live board data via pcbnew.

This module MUST run inside KiCad (either as an ActionPlugin or in the
Scripting Console), because `pcbnew` is only importable there. It cannot
be tested outside KiCad.
"""

import pcbnew


def read_footprints(board):
    """Return a list of dicts, one per footprint on the board."""
    footprints = []
    for fp in board.GetFootprints():
        pos = fp.GetPosition()
        footprints.append({
            "reference": fp.GetReference(),
            "value": fp.GetValue(),
            "footprint": str(fp.GetFPID().GetLibItemName()),
            "layer": fp.GetLayerName(),
            "x_mm": pcbnew.ToMM(pos.x),
            "y_mm": pcbnew.ToMM(pos.y),
            "dnp": bool(fp.IsDNP()) if hasattr(fp, "IsDNP") else False,
        })
    return footprints


def read_board_summary(board):
    """
    Return board-level counts that don't belong to any single footprint:
    tracks, vias, pads, nets, copper layers.
    """
    tracks = 0
    vias = 0
    for t in board.GetTracks():
        if isinstance(t, pcbnew.PCB_VIA):
            vias += 1
        else:
            tracks += 1

    pad_count = sum(len(fp.Pads()) for fp in board.GetFootprints())
    net_count = board.GetNetInfo().GetNetCount()
    copper_layers = board.GetCopperLayerCount()

    return {
        "board_file": board.GetFileName(),
        "track_count": tracks,
        "via_count": vias,
        "pad_count": pad_count,
        "net_count": net_count,
        "copper_layer_count": copper_layers,
    }


def read_board(board):
    """Convenience wrapper combining footprints + summary."""
    return {
        "footprints": read_footprints(board),
        "summary": read_board_summary(board),
    }
