"""
Datasheet collector - pure Python, no pcbnew dependency.
"""


def collect_datasheets(bom_rows):
    """
    From a grouped BOM (see core.bom.group_bom), return a de-duplicated
    list of {value, reference_range, datasheet} for every row that has
    a real datasheet link (skips blank / '~' entries).
    """
    seen = set()
    result = []
    for row in bom_rows:
        ds = (row.get("datasheet") or "").strip()
        if not ds or ds == "~":
            continue
        key = (row["value"], ds)
        if key in seen:
            continue
        seen.add(key)
        result.append({
            "value": row["value"],
            "reference_range": row["reference_range"],
            "datasheet": ds,
        })
    return result
