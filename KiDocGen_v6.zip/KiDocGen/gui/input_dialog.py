import os
import urllib.parse
import wx
import wx.html2 as webview


class ProjectInputDialog(wx.Dialog):
    """
    Hosts gui/input_form.html inside a WebView.

    Bridge protocol (no server needed - just intercepted navigation):
      kidocgen:submit?field=value&field2=value2   -> form submitted, close OK
      kidocgen:cancel                              -> user cancelled
      kidocgen:browse                              -> open a native folder picker,
                                                       then push the path back into
                                                       the page via RunScript()
    """

    def __init__(self, parent, default_project_dir=""):
        super().__init__(
            parent,
            title="KiDocGen - Report Details",
            size=(600, 680),
            style=wx.DEFAULT_DIALOG_STYLE | wx.RESIZE_BORDER,
        )

        self.default_project_dir = default_project_dir
        self.form_data = {}

        sizer = wx.BoxSizer(wx.VERTICAL)
        self.browser = webview.WebView.New(self)
        sizer.Add(self.browser, 1, wx.EXPAND)
        self.SetSizer(sizer)

        html_path = os.path.join(os.path.dirname(__file__), "input_form.html")
        html_url = "file://" + html_path.replace("\\", "/")
        self.browser.LoadURL(html_url)

        self.browser.Bind(webview.EVT_WEBVIEW_NAVIGATING, self.on_navigating)

        # Prefill the output folder once the page has finished loading
        self.browser.Bind(webview.EVT_WEBVIEW_LOADED, self.on_loaded)

    def on_loaded(self, event):
        safe_dir = self.default_project_dir.replace("\\", "\\\\").replace("'", "\\'")
        self.browser.RunScript(
            f"document.getElementById('output_dir').value = '{safe_dir}';"
        )

    def on_navigating(self, event):
        url = event.GetURL()

        if url.startswith("kidocgen:submit"):
            event.Veto()
            query = url.split("?", 1)[1] if "?" in url else ""
            parsed = urllib.parse.parse_qs(query, keep_blank_values=True)
            self.form_data = {k: v[0] for k, v in parsed.items()}
            if not self.form_data.get("output_dir"):
                self.form_data["output_dir"] = self.default_project_dir
            self.EndModal(wx.ID_OK)

        elif url.startswith("kidocgen:cancel"):
            event.Veto()
            self.EndModal(wx.ID_CANCEL)

        elif url.startswith("kidocgen:browse"):
            event.Veto()
            dlg = wx.DirDialog(self, "Choose output folder",
                                defaultPath=self.default_project_dir)
            if dlg.ShowModal() == wx.ID_OK:
                path = dlg.GetPath().replace("\\", "\\\\").replace("'", "\\'")
                self.browser.RunScript(
                    f"document.getElementById('output_dir').value = '{path}';"
                )
            dlg.Destroy()

    def get_form_data(self):
        return self.form_data
